package RecursionPartIII;

public final class RecursionClass {

	public static void pattern(int x, int y ) {
		
		
		
	}
}
