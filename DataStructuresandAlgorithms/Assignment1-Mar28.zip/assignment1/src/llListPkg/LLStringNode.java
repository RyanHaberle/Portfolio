package llListPkg;
public class LLStringNode<T> {

	private T info;
	  private LLStringNode<T> link;
	  
	  public LLStringNode(T info) {
	    this.info = info;
	    link = null;
	  }
	  

	  public void setInfo(T info)
	  {
	    this.info = info;
	  }
	  

	  public T getInfo()
	  {
	    return info;
	  }
	  
	  public void setLink(LLStringNode<T> link)
	  {
	    this.link = link;
	  }
	  
	  public LLStringNode<T> getLink()
	  {
	    return link;
	  }
}
