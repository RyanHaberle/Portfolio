package llListPkg;

public class LinkedSequence<T> extends java.lang.Object implements java.lang.Cloneable {

	protected LLStringNode<T> log, currNode;
	protected String id;
	protected static int length = 0;

	public LinkedSequence(String _id) {
		log = null;
		currNode = null;
		id = _id;
	}
	
	public void addAfter(T element) /////////////////////////////////////////////////////////////////////
	{
		if(isCurrent())  // isCurrent - If pointer is pointing at a node, new element will be added after that node
		{      
			LLStringNode<T> newNode = new LLStringNode<T>(element);   //create new node
		    newNode.setLink(currNode.getLink());                      // set new node linked to one after currNode
		    currNode.setLink(newNode);                                // Link currNode to the new Node
		    length++;                                                 //increment length of list
		}
		else   // If the pointer is not pointing anywhere on the list isCurrent() is false
		{
			LLStringNode<T> newNode = new LLStringNode<T>(element);
			while( currNode.getLink() != null) 
			{                    // If not pointer not pointing at a node, increment pointer with advance() 
				                 //function and add element at end of list.
			    advance();
			    if(currNode.getLink() == null) 
			    {
			    	currNode.setLink(newNode);                            // sets new node to end of list
			    	length++;                                             // increment length of the list
			    }
			}
		}
	}
	
	public void addBefore(T element) //////// Adds a node before current Node.
	{
		if(isCurrent()) // isCurrent Checks if there is a current element.
		{
		LLStringNode<T> tempNode = currNode;                     // save currNode in a temp space as a marker
		start();                                                 // sets currNode back to the start of the list.
		LLStringNode<T> newNode = new LLStringNode<T>(element);  //make a new node.
		while(currNode.getLink()!= tempNode.getInfo()) 
		{
			advance();                                            // Increment currNode to behind tempCurrNode.
			
		}
		if(currNode.getLink() == tempNode.getInfo())              //once currNode is behind tempNode
		{
			newNode.setLink(tempNode);                            //set newNode link to tempNode
			currNode.setLink(newNode);                            // set currNode links to the new node.
			length++;
		}
	}else 
	{
		currNode.setLink(log.getLink()); 
	    currNode = log;
	    length++;
	}
		
	}
	void removeCurrent(T element)  // removes the node the current node is on./////////////////////////////////////////////////
	{
		LLStringNode<T> tempNode = currNode;                      // saves current nodes spot in a temp variable
		LLStringNode<T> newNode = new LLStringNode<T>(element);
		start();
		while(currNode.getLink() != tempNode.getInfo())           //if the currNode is not behind TempNode advance()
		{
			advance();
		}
		if(currNode.getLink() == tempNode.getInfo())              // when currNode is behind TempNode
		{
			currNode.setLink(tempNode.getLink());  
			length--;
		// Set the current nodes link to the tempNodes link to get rid of the temp node.                                        
		}
		
		
	}
	
	boolean isCurrent() //will return true if pointer is set to a node, False if not.///////////////////////////////////
	{
		
		if(currNode.getInfo() != null) 
		{
			return true;
		}
		return false;
	}
	
	void advance() 
	{
	if(isCurrent()) //Will increment to next node every time advance() is called and 
	{
		
		currNode = currNode.getLink();
	}	
	}
	
	void start() {  ////// sends the pointer currNode back to the start of the list ////////////////////
		if( size() >= 1) // If if there are elements in the list set to beginning
		{
			currNode = log.getLink(); // set current node back to start
		}
		else
		{
			currNode = null; // there are not elements in the list
		}
	}
	
	public int size() 
	{
		return length;
	}
 
	

	
}
