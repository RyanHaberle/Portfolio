import java.math.BigInteger;
public class Driver {
	
	public static Stopwatch timer;
	public static void main(String[] args) {
		System.out.println("----------------------------------------");
		findDaffy(30,44);
		/*System.out.println("----------------------------------------");
		findDonald(30,44);
		System.out.println("----------------------------------------");
		findMickey(1000,8192000);
		System.out.println("----------------------------------------");
		findMinnie(1000,256000);
		System.out.println("----------------------------------------");
		findGoofy(1000,256000);
		System.out.println("----------------------------------------");
		findPluto(1000,256000);
		System.out.println("----------------------------------------");
		findGyro(1000,256000);
		System.out.println("----------------------------------------");
		findFact(1000,64000);
		System.out.println("----------------------------------------");*/

	}
	
	public static void findDaffy(int start , int stop) {
		timer = new Stopwatch();
		for(int n = start ; n <= stop ; n++) {
			timer.start();
			Timing.daffy(n);
			timer.stop();
			System.out.println("Number of Arguments: "+n+" "+timer
					+" This is time in nanosecond(ten raise to minus 9): "
					+timer.timeInNanoseconds()+"\n");
		}
	}
	
	public static void findDonald(int start , int stop) {
		timer = new Stopwatch();
		for(int n = start ; n <= stop ; n++) {
			timer.start();
			Timing.donald(n);
			timer.stop();
			System.out.println("Number of Arguments: "+n+" "+timer
					+" This is time in nanosecond(ten raise to minus 9): "
					+timer.timeInNanoseconds()+"\n");
		}
	}
	
	public static void findMickey(int start, int stop) {
		timer = new Stopwatch();
		for(int nos = start ; nos <= stop ; nos*=2) {
			int[] data = Timing.randomarr(nos);
			timer.start();
			Timing.mickey(data);
			timer.stop();
			System.out.println("Number of Arguments: "+nos+" "+timer
					+" This is time in nanosecond(ten raise to minus 9: )"
					+timer.timeInNanoseconds()+"\n");
		}
		
	}

	public static void findMinnie(int start , int stop) {
		timer = new Stopwatch();
		for(int nos = start ; nos <= stop ; nos*=2) {
			int[] data = Timing.randomarr(nos);
			timer.start();
			Timing.minnie(data);
			timer.stop();
			System.out.println("Number of Arguments: "+nos+" "+timer
					+" This is time in nanosecond(ten raise to minus 9: )"
					+timer.timeInNanoseconds()+"\n");
		}
	}
	
	public static void findGoofy(int start , int stop) {
		timer = new Stopwatch();
		for(int nos = start ; nos <= stop ; nos*=2) {
			int[] data = Timing.randomarr(nos);
			timer.start();
			Timing.goofy(data);
			timer.stop();
			System.out.println("Number of Arguments: "+nos+" "+timer
					+" This is time in nanosecond(ten raise to minus 9: )"
					+timer.timeInNanoseconds()+"\n");
		}
	}
		
		public static void findPluto(int start , int stop) {
			timer = new Stopwatch();
			for(int nos = start ; nos <= stop ; nos*=2) {
				int[] data = Timing.randomarr(nos);
				timer.start();
				Timing.pluto(data);
				timer.stop();
				System.out.println("Number of Arguments: "+nos+" "+timer
						+" This is time in nanosecond(ten raise to minus 9: )"
						+timer.timeInNanoseconds()+"\n");
			}
	}
		
		public static void findGyro(int start, int stop) {
			timer = new Stopwatch();
			for(int nos = start; nos <= stop; nos*=2) {
				int[] data = Timing.randomarr(nos);
				Timing.pluto(data);
				timer.start();
				Timing.gyro(data);
				timer.stop();
				System.out.println("Number of Arguments: "+nos+" "+timer
						+" This is time in nanosecond(ten raise to minus 9: )"
						+timer.timeInNanoseconds()+"\n");
			}
		}
		
		public static void findFact(int start , int stop) {
			timer = new Stopwatch();
			for(int number = start ; number <= stop ; number*=2) {
				BigInteger bign = BigInteger.valueOf((long) number);
				timer.start();
				Timing.fact(bign);
				timer.stop();
				System.out.println("Number of Arguments: "+number+" "+timer
						+" This is time in nanosecond(ten raise to minus 9: )"
						+timer.timeInNanoseconds()+"\n");
			}
			
		}
		
		
		
}
